
public class TreesPrac {

	//put the tree in queue and print the queue
	public static<T> void widthOrder(BinNode<T> tree){
		int count = 0;
		Queue<BinNode> queue = new Queue<BinNode>();
		queue.insert(tree);
		while(!queue.isEmpty()){
			BinNode tree1 = queue.remove();
			System.out.print(tree1.getValue());
			if(tree1.hasLeft()){
				queue.insert(tree1.getLeft());
			}
			if(tree1.hasRight()){
				queue.insert(tree1.getRight());
			}
		}
	}

	//the height of the tree
	public static<T> int height(BinNode<T> tree){
		if (tree == null){
			return -1;
		}
		if (leaf(tree)){
			return 0;
		}
		else{
			int lHeight = height(tree.getLeft());
			int rHeight = height(tree.getRight());
			if (lHeight > rHeight){
				return 1 + lHeight;
			}
			else{
				return 1 + rHeight;
			}
		}
	}

	//tzomet, left, right
	public static<T> void preOrder(BinNode<T> tree){
		if (tree!=null) {
			System.out.print(tree.getValue());
			preOrder(tree.getLeft());
			preOrder(tree.getRight());
		}
	}
	//left, tzomet, right
	public static<T> void inOrder(BinNode<T> tree){
		if (tree!=null) {
			inOrder(tree.getLeft());
			System.out.print(tree.getValue());
			inOrder(tree.getRight());
		}
	}
	//left, right, ztomet
	public static<T> void postOrder(BinNode<T> tree){
		if (tree!=null) {
			postOrder(tree.getLeft());
			postOrder(tree.getRight());
			System.out.print(tree.getValue());
		}
	}

	//if the number is in the tree
	public static boolean inTree(BinNode<Integer> tree, int num){
		if (tree!=null) {
			if (tree.getValue() == num){
				return true;
			}
			else{
				if (inTree(tree.getLeft(), num) || inTree(tree.getRight(), num)){
					return true;
				}
				return false;
			}
		}
		else{
			return false;
		}
	}

	//the length of the tree
	public static<T> int treeLen(BinNode<Integer> tree){
		if (tree==null){
			return 0;
		}
		else{
			return 1 + treeLen(tree.getLeft()) + treeLen(tree.getRight());
		}
	}


	public static<T> boolean leaf(BinNode<T> tree){
		return !tree.hasLeft() && !tree.hasRight();
	}

	//print all the zoogi numbers in the tree
	public static void zoogi(BinNode<Integer> tree){
		if (tree!=null) {
			if (tree.getValue()%2 == 0){
				System.out.print(tree.getValue());
			}
			zoogi(tree.getLeft());
			zoogi(tree.getRight());
		}
	}

	//count how much ztomets have right son
	public static int yemanim(BinNode<Integer> tree){
		if (tree == null){
			return 0;
		}
		else{
			if (tree.hasRight()){
				return 1 + yemanim(tree.getRight()) + yemanim(tree.getRight());
			}
			return yemanim(tree.getLeft());
		}
	}

	//how much time the number is in the tree
	public static int numInTree(BinNode<Integer> tree, int num){
		if (tree == null){
			return 0;
		}
		else{
			if (tree.getValue() == num){
				return 1 + numInTree(tree.getRight(), num) + numInTree(tree.getLeft(), num);
			}
			else{
				return numInTree(tree.getRight(), num) + numInTree(tree.getLeft(), num);
			}
		}
	}

	//all the tzomets that has two sons, the left one is bigger
	public static boolean leftBigger(BinNode<Integer> tree){
		if (tree == null){
			return true;
		}
		else{
			if (tree.hasLeft() && tree.hasRight()){
				if (tree.getLeft().getValue() > tree.getRight().getValue()){
					leftBigger(tree.getLeft());
					leftBigger(tree.getRight());
					return true;
				}
				else {
					return false;
				}
			}
			else{
				leftBigger(tree.getLeft());
				leftBigger(tree.getRight());
				return true;
			}
		}
	}

	//add number to the left ztomet in the tree
	public static void addNum(BinNode<Integer> tree, int num){
		if (leaf(tree)){
			tree.setLeft(new BinNode<Integer>(num));
		}
		else{
			addNum(tree.getLeft(), num);
		}
	}

	//the tree hafuch
	public static void hafuch(BinNode<Integer> tree){
		if (tree != null){
			if (tree.hasLeft() && tree.hasRight()){
				BinNode<Integer> right = tree.getRight();
				BinNode<Integer> left = tree.getLeft();
				tree.setLeft(right);
				tree.setRight(left);
			}
			if (tree.hasLeft() && !tree.hasRight()){
				BinNode<Integer> right = null;
				BinNode<Integer> left = tree.getLeft();
				tree.setLeft(right);
				tree.setRight(left);
			}
			if (!tree.hasLeft() && tree.hasRight()){
				BinNode<Integer> right = tree.getRight();
				BinNode<Integer> left = null;
				tree.setLeft(right);
				tree.setRight(left);
			}
			hafuch(tree.getLeft());
			hafuch(tree.getRight());
		}
	}

	//all the brothers are same
	public static boolean bro(BinNode<Integer> tree){
		if (tree == null){
			return true;
		}
		if (leaf(tree)){
			return true;
		}
		else{
			if (tree.hasLeft() && !tree.hasRight()){
				return bro(tree.getLeft());
			}
			if (!tree.hasLeft() && tree.hasRight()){
				return bro(tree.getRight());
			}

			else{
				if (tree.getLeft().getValue() != tree.getRight().getValue()){
					return false;
				}
				return bro(tree.getLeft()) && bro(tree.getRight());
			}
		}
	}

	//sum all the ztomets that bigger that the father
	public static int sumBiggerDad(BinNode<Integer> tree, int father){
		if (tree == null){
			return 0;
		}
		else {
			if (tree.getValue() > father && father!=-1){
				if (tree.hasLeft() && tree.hasRight()){
					return tree.getValue()+sumBiggerDad(tree.getLeft(), tree.getValue())+sumBiggerDad(tree.getRight(), tree.getValue());
				}
				if (tree.hasLeft() && !tree.hasRight()){
					return tree.getValue()+sumBiggerDad(tree.getLeft(), tree.getValue());
				}
				if (!tree.hasLeft() && tree.hasRight()){
					return tree.getValue()+sumBiggerDad(tree.getRight(), tree.getValue());
				}
				return tree.getValue();
			}
			else{
				if (tree.hasLeft() && tree.hasRight()){
					return sumBiggerDad(tree.getLeft(), tree.getValue())+sumBiggerDad(tree.getRight(), tree.getValue());
				}
				if (tree.hasLeft() && !tree.hasRight()){
					return sumBiggerDad(tree.getLeft(), tree.getValue());
				}
				if (!tree.hasLeft() && tree.hasRight()){
					return sumBiggerDad(tree.getRight(), tree.getValue());
				}
				return 0;
			}
		}
	}

	//delete tzomets with the number
	public static void delNum(BinNode<Integer> tree, int num){
		if (tree!=null) {
			if (tree.hasLeft()){
				if (tree.getLeft().getValue() == num){
					tree.setLeft(null);
				}
			}
			if (tree.hasRight()){
				if (tree.getRight().getValue() == num){
					tree.setRight(null);
				}
			}
			delNum(tree.getLeft(), num);
			delNum(tree.getRight(), num);
		}
	}

	//tree to stack
	public static Stack<Integer> treeToStack(BinNode<Integer> tree, Stack<Integer> stack){
		if (tree!=null) {
			stack.push(tree.getValue());
			treeToStack(tree.getLeft(), stack);
			treeToStack(tree.getRight(), stack);
		}
		return stack;
	}

	//max of tree
	public static int maxTree(BinNode<Integer> tree, int max){
		if (tree==null){
			return max;
		}
		else{
			max = Math.max(max, tree.getValue());
			return Math.max(maxTree(tree.getLeft(), max), maxTree(tree.getRight(), max));
		}
	}

	//if the tree is meuzan
	public static boolean meuzan(BinNode<Integer> tree){
		if (tree==null){
			return true;
		}
		else{
			if (height(tree.getLeft()) == height(tree.getRight())){
				return meuzan(tree.getLeft()) && meuzan(tree.getRight());
			}
			return false;
		}
	}

	//add the number to the leafs that bigger than the number
	public static void addLeafs(BinNode<Integer> tree, int num){
		if (tree!=null){
			if (leaf(tree)){
				if (num < tree.getValue()){
					tree.setRight(new BinNode<Integer>(num));
				}
			}
			else{
				addLeafs(tree.getLeft(), num);
				addLeafs(tree.getRight(), num);
			}
		}
	}


	public static void main(String[] args)
	{
		BinNode<Integer> n8 = new BinNode<Integer>(8);
		BinNode<Integer> n7 = new BinNode<Integer>(7);
		BinNode<Integer> n6 = new BinNode<Integer>(6);
		BinNode<Integer> n5 = new BinNode<Integer>(n6, 5, null);
		BinNode<Integer> n4 = new BinNode<Integer>(4);
		BinNode<Integer> n3 = new BinNode<Integer>(n4, 3, n5);
		BinNode<Integer> n2 = new BinNode<Integer>(n7, 2, n8);
		BinNode<Integer> n1 = new BinNode<Integer>(n2, 1, n3);
		
	}

}
