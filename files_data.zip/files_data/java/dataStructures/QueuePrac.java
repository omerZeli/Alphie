import java.util.Random;

public class QueuePrac {

	//build a queue
	public static Queue<Integer> build(){
		Queue<Integer> queue = new Queue<Integer>();
		Random rand = new Random();
		for (int i = 0; i < 10; i++) {
			queue.insert(rand.nextInt(10));
		}
		return queue;
	}

	//clone queue
	public static <T> Queue<T> cloneQ(Queue<T> queue){
		Queue<T> temp1 = new Queue<T>();
		Queue<T> temp2 = new Queue<T>();
		T x;
		while (!queue.isEmpty()) {
			x = queue.remove();
			temp1.insert(x);
			temp2.insert(x);
		}
		while (!temp1.isEmpty()){
			queue.insert(temp1.remove());
		}
		while (!temp2.isEmpty()){
			temp1.insert(temp2.remove());
		}
		return temp1;
	}

	//find length
	public static int length(Queue<Integer> queue){
		Queue<Integer> temp = cloneQ(queue);
		int len = 0;
		while (!temp.isEmpty()){
			len++;
			temp.remove();
		}
		return len;
	}

	//find max
	public static int findMax(Queue<Integer> queue){
		Queue<Integer> temp = cloneQ(queue);
		int max = temp.remove();
		while (!temp.isEmpty()){
			if (max < temp.head()){
				max = temp.head();
			}
			temp.remove();
		}
		return max;
	}

	//if the num is in the queue
	public static boolean inQueue(Queue<Integer> queue, int num){
		Queue<Integer> temp = cloneQ(queue);
		while (!temp.isEmpty()){
			if (temp.head() == num){
				return true;
			}
			temp.remove();
		}
		return false;
	}



}
