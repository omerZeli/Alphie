import java.util.Random;

import javax.swing.text.html.HTMLDocument.HTMLReader.HiddenAction;

public class General {

	//clone queue
	public static <T> Queue<T> cloneQ(Queue<T> queue){
		Queue<T> temp1 = new Queue<T>();
		Queue<T> temp2 = new Queue<T>();
		T x;
		while (!queue.isEmpty()) {
			x = queue.remove();
			temp1.insert(x);
			temp2.insert(x);
		}
		while (!temp2.isEmpty()){
			queue.insert(temp2.remove());
		}
		return temp1;
	}

	//clone stack
	public static <T> Stack<T> cloneS(Stack<T> stack){
		Stack<T> temp1 = new Stack <T>();
		Stack<T> temp2 = new Stack <T>();
		T x;
		while (!stack.isEmpty()) {
			x = stack.pop();
			temp1.push(x);
			temp2.push(x);
		}
		while (!temp1.isEmpty()){
			stack.push(temp1.pop());
		}
		while (!temp2.isEmpty()){
			temp1.push(temp2.pop());
		}
		return temp1;
	}

	//queue length
	public static<T> int queueLen(Queue<T> queue){
		int count = 0;
		Queue<T> q = cloneQ(queue);
		while (!q.isEmpty()){
			q.remove();
			count++;
		}
		return count;
	}

	//list length
	public static int listLen(Node<Integer> list){
		int count = 0;
		Node<Integer> temp = list;
		while (temp.hasNext()){
			temp = temp.getNext();
			count++;
		}
		return count+1;
	}

	//height of tree
	public static int height(BinNode<Integer> tree){
		if (tree==null){
			return -1;
		}
		else{
			return 1+Math.max(height(tree.getLeft()), height(tree.getRight()));
		}
	}

	//remove the last in the stack
	public static int lastRemove(Stack<Integer> s){
		Stack<Integer> ns = new Stack<Integer>();
		while (!s.isEmpty()){
			ns.push(s.pop());
		}
		int last = ns.pop();
		while (!ns.isEmpty()){
			s.push(ns.pop());
		}
		return last;
	}

	//if the number is less than all the tree
	public static boolean lessTree(BinNode<Integer> tree, int num){
		if (tree.getValue() < num){
			return false;
		}
		if (tree.hasLeft()){
			return lessTree(tree.getLeft(), num);
		}
		if (tree.hasRight()){
			return lessTree(tree.getRight(), num);
		}
		else{
			return true;
		}
	}

	//take the last number in the queue
	public static int takeLast(Queue<Integer> queue){
		Queue<Integer> q = new Queue<>();
		while (queueLen(queue) != 1){
			q.insert(queue.remove());
		}
		int num = queue.remove();
		while (!q.isEmpty()){
			queue.insert(q.remove());
		}
		return num;
	}

	//if the num is in the tree
	public static boolean exist(BinNode<Integer> tree, int num){
		if (tree==null){
			return false;
		}
		else if (tree.getValue() == num){
			return true;
		}
		else{
			return exist(tree.getLeft(), num) || exist(tree.getRight(), num);
		}
	}

	//the max of the tree
	public static int maxT(BinNode<Integer> tree){
		if (tree!=null){
			int left = Math.max(tree.getValue(), maxT(tree.getLeft()));
			int right = Math.max(tree.getValue(), maxT(tree.getRight()));
			return Math.max(left, right);
		}
		else{
			return 0;
		}
	}

	//put the tree in string
	public static String inOrderStr(BinNode<Character> t){
		if (t==null){
			return "";
		}
		else{
			return inOrderStr(t.getLeft()) + t.getValue() + inOrderStr(t.getRight());
		}
	}

	//bubbleSort, o(n**2)
	public static Node<Character> bubbleSortChar(Node<Character> list){
		char x; int counter = 0, current = 0;
		boolean flag = true;
		Node<Character> temp = list;
		while(temp != null) {
			counter++;
			temp=temp.getNext();
		}
		current = counter;
		while (flag){
			flag = false;
			current = counter;
			temp = list;
			while (current>1) {
				if (temp.getValue() > temp.getNext().getValue()) {
					x = temp.getValue();
					temp.setValue(temp.getNext().getValue());
					temp.getNext().setValue(x);
					flag = true;
				}
				temp = temp.getNext();
				current--;
			}
			counter--;
		}
		return list;
	}

	//the lsat in the queue
	public static int lastQueue(Queue<Integer> queue){
		Queue<Integer> q = cloneQ(queue);
		int last = -1;
		while(!q.isEmpty()){
			last = q.remove();
		}
		return last;
	}

	public static<T> void inOrder(BinNode<T> tree){
		if (tree!=null) {
			inOrder(tree.getLeft());
			System.out.print(tree.getValue());
			inOrder(tree.getRight());
		}
	}

	//bubble sort arr
	public static void sortArr(int[] arr) { 
		for (int i = 0; i < arr.length-1; i++) {
			for (int j = 0; j < arr.length-i-1; j++) {
				if (arr[j] > arr[j+1]){ 
					int temp = arr[j]; 
					arr[j] = arr[j+1]; 
					arr[j+1] = temp; 
				} 
			}
		}
	} 

	//min in list
	public static int minList(Node<Integer> list){
		Node<Integer> temp = list;
		int min = temp.getValue();
		while(temp.hasNext()){
			temp = temp.getNext();
			min = Math.min(min, temp.getValue());
		}
		return min;
	}

	//delete num from list
	public static Node<Integer> delete(Node<Integer> list, int num){
		Node<Integer> temp = list;
		if(temp.getValue() == num){
			return temp.getNext();
		}
		boolean flag = false;
		while(temp.hasNext() && !flag){
			if(temp.getNext().getValue() == num){
				temp.setNext(temp.getNext().getNext());
				flag = true;
			}
		}
		return list;
	}

	public static boolean simetric(BinNode<Integer> t){
		if(!t.hasLeft() && !t.hasRight()){
			return true;
		}
		if((t.hasLeft() && !t.hasRight()) || (!t.hasLeft() && t.hasRight())){
			return false;
		}
		else{
			return height(t.getLeft())==height(t.getRight());
		}
	}

	public static int countSimetric(BinNode<Integer> t){
		if(t==null){
			return 0;
		}
		else{
			if (simetric(t)){
				return 1+countSimetric(t.getLeft())+countSimetric(t.getRight());
			}
			else{
				return countSimetric(t.getLeft())+countSimetric(t.getRight());
			}
		}
	}



	public static void main(String[] args) {
		//		Queue<Integer> queue = new Queue<Integer>();
		//		queue.insert(1);
		//		queue.insert(2);
		//		queue.insert(3);
		//		queue.insert(4);
		//		queue.insert(5);
		//		queue.insert(6);
		//		Node<Integer> n6 = new Node<Integer>(2);
		//		Node<Integer> n5 = new Node<Integer>(1, n6);
		//		Node<Integer> n4 = new Node<Integer>(2, n5);
		//		Node<Integer> n3 = new Node<Integer>(3, n4);
		//		Node<Integer> n2 = new Node<Integer>(2, n3);
		//		Node<Integer> n1 = new Node<Integer>(1, n2);
		//		Stack<Integer> stack = new Stack<Integer>();
		//		stack.push(4);
		//		stack.push(1);
		//		stack.push(3);
		//		stack.push(2);
		//		stack.push(5);
		BinNode<Integer> n8 = new BinNode<Integer>(8);
		BinNode<Integer> n7 = new BinNode<Integer>(7);
		BinNode<Integer> n6 = new BinNode<Integer>(6);
		BinNode<Integer> n5 = new BinNode<Integer>(n6, 5, null);
		BinNode<Integer> n4 = new BinNode<Integer>(4);
		BinNode<Integer> n3 = new BinNode<Integer>(n4, 3, n5);
		BinNode<Integer> n2 = new BinNode<Integer>(n7, 2, n8);
		BinNode<Integer> n1 = new BinNode<Integer>(n2, 1, n3);
		
		System.out.println(simetric(n1));



	}

}
