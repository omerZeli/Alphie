import java.util.Random;

public class StacksPrac {

	//clone stack
	public static <T> Stack<T> cloneS(Stack<T> stack){
		Stack<T> temp1 = new Stack <T>();
		Stack<T> temp2 = new Stack <T>();
		T x;
		while (!stack.isEmpty()) {
			x = stack.pop();
			temp1.push(x);
			temp2.push(x);
		}
		while (!temp1.isEmpty()){
			stack.push(temp1.pop());
		}
		while (!temp2.isEmpty()){
			temp1.push(temp2.pop());
		}
		return temp1;
	}

	//build a stack
	public static Stack<Integer> build(){
		Stack<Integer> stack = new Stack<Integer>();
		Random rand = new Random();
		for (int i = 0; i < 10; i++) {
			stack.push(rand.nextInt(10));
		}
		return stack;
	}

	//stack length
	public static<T> int length(Stack<T> stack) {
		Stack<T> temp = cloneS(stack);
		int len = 0;
		while (!temp.isEmpty()) {
			len++;
			temp.pop();
		}
		return len;
	}

	//find minimum - rex
	public static <T> int minInStack (int min, Stack<Integer> stack){
		Stack<Integer> temp = cloneS(stack);
		if(temp.isEmpty()){
			return min;
		}
		else {
			if (temp.top()<min) {
				min=temp.top();
			}
			temp.pop();
			return minInStack(min,temp);
		}
	}

	//check if the variable is in the stack
	public static <T> boolean inStack (T x, Stack<Integer> stack){
		Stack<Integer> temp = cloneS(stack);
		while(temp.isEmpty() == false){
			if(temp.top() == x){
				return true;
			}
			temp.pop();
		}	
		return false;
	}

	//check how much times the variable is in the stack
	public static <T> int howMuchInStack(T x, Stack<Integer> stack){
		Stack <Integer> temp = cloneS(stack);
		int count=0;
		while (temp.isEmpty() == false) {
			if (temp.top() == x) {
				count++;
			}
			temp.pop();
		}
		return count;
	}


	//return the number in the wanted place of the stack
	public static int putInStack (int wantedPlace, Stack<Integer> stack){
		Stack<Integer> useStack = cloneS(stack);
		int currentPlace = 1;
		while(currentPlace<wantedPlace){
			useStack.pop();
			currentPlace++;
		}
		return useStack.pop();
	}

//	//add the num
//	public static Stack<Queue> add(Stack<Queue> stack, int num){
//		Stack<Queue> temp = cloneS(stack);
//		int count = length(temp);
//		while(count!=0){
//			temp = cloneS(stack);
//			for (int i = 0; i < count-1; i++) {
//				temp.pop();
//			}
//			if (!inQueue(temp.top(), num)){
//				temp.top().insert(num);
//				return stack;
//			}
//			count--;
//		}
//		Queue<Integer> newQueue = new Queue<Integer>();
//		newQueue.insert(num);
//		stack.push(newQueue);
//		return stack;
//	}



}
