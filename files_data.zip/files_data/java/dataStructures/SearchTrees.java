
public class SearchTrees {

	public static<T> void inOrder(BinNode<T> tree){
		if (tree!=null) {
			inOrder(tree.getLeft());
			System.out.print(tree.getValue() + ", ");
			inOrder(tree.getRight());
		}
	}

	//add num to the the tree
	public static void addNum(BinNode<Integer> tree, int num){
		if (tree.getValue() > num){
			if (!tree.hasLeft()){
				tree.setLeft(new BinNode<Integer>(num));
			}
			else{
				addNum(tree.getLeft(), num);
			}
		}
		else{
			if (!tree.hasRight()){
				tree.setRight(new BinNode<Integer>(num));
			}
			else{
				addNum(tree.getRight(), num);
			}
		}
	}

	//if the num is in the tree
	public static boolean inTree(BinNode<Integer> tree, int num){
		if (tree == null){
			return false;
		}
		if (tree.getValue() == num){
			return true;
		}
		if (tree.getValue() > num){
			if (!tree.hasLeft()){
				return false;
			}
			return inTree(tree.getLeft(), num);
		}
		else{
			if(!tree.hasRight()){
				return false;
			}
			return inTree(tree.getRight(), num);
		}
	}

	
	
	public static void main(String[] args) {
		BinNode<Integer> n7 = new BinNode<Integer>(26);
		BinNode<Integer> n6 = new BinNode<Integer>(11);
		BinNode<Integer> n5 = new BinNode<Integer>(n6, 13, null);
		BinNode<Integer> n4 = new BinNode<Integer>(5);
		BinNode<Integer> n3 = new BinNode<Integer>(null, 16, n7);
		BinNode<Integer> n2 = new BinNode<Integer>(n4, 10, n5);
		BinNode<Integer> n1 = new BinNode<Integer>(n2, 15, n3);

		inOrder(n1);
		System.out.println();
		System.out.println(inTree(n1, 12));


	}

}
