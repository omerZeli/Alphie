import java.util.Scanner;

public class NodesPrac {

	//create list from the beginning - for
	public static Node<Integer> buildFor1(int listLen){
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		Node<Integer> first = new Node<Integer>(num);
		Node<Integer> temp1 = first;
		Node<Integer> temp2;
		for (int i = 1; i < listLen; i++) {
			num = scan.nextInt();
			temp2 = new Node<Integer>(num);
			temp1.setNext(temp2);
			temp1 = temp1.getNext();
		}
		return first;
	}

	//create list from the end - for
	public static Node<Integer> buildFor2(int listLen){
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		Node<Integer> first = new Node<Integer>(num);
		Node<Integer> temp1;
		for (int i = 1; i < listLen; i++) {
			num = scan.nextInt();
			temp1 = new Node<Integer>(num);
			temp1.setNext(first);
			first = temp1;
		}
		return first;
	}

	//create list from the beginning - rex
	public static Node<Integer> buildRex1(Node<Integer> first, Node<Integer> last, int listLen){
		Scanner scan = new Scanner(System.in);
		if (listLen == 0) {
			return first;
		}
		if (first == null) {
			int num = scan.nextInt();
			first = new Node<Integer>(num);
			last = first;
			return buildRex1(first, last, listLen-1);
		}
		else {
			int num = scan.nextInt();
			last.setNext(new Node<Integer>(num));
			last = last.getNext();
			return buildRex1(first, last, listLen-1);
		}
	}

	//create list from the end - rex
	public static Node<Integer> buildRex2(Node<Integer> first, int listLen){
		Scanner scan = new Scanner(System.in);
		if (listLen == 0) {
			return first;
		}
		if (first == null) {
			int num = scan.nextInt();
			first = new Node<Integer>(num);
			return buildRex2(first, listLen-1);
		}
		else {
			int num = scan.nextInt();
			Node<Integer> temp = new Node<Integer>(num);
			temp.setNext(first);
			return buildRex2(temp, listLen-1);
		}
	}

	//the lentgh of the list
	public static int listLen(Node<Integer> first) {
		Node<Integer> temp = first;
		int count = 1;
		while (temp.hasNext()) {
			temp = temp.getNext();
			count++;
		}
		return count;
	}

	//print the list
	public static void printList(Node<Integer> first) {
		Node<Integer> temp = first;
		while (temp.hasNext()) {
			System.out.println(temp.getValue());
			temp = temp.getNext();
		}
		System.out.println(temp.getValue());
	}

	//the last node in the list
	public static Node<Integer> last(Node<Integer> first){
		Node<Integer> temp = first;
		while(temp.hasNext()) {
			temp = temp.getNext();
		}
		return temp;
	}

	//delete the last node
	public static void delLast(Node<Integer> first){
		while(first.getNext().hasNext()) {
			first = first.getNext();
		}
		first.setNext(null);
	}

	//check if the number is in the list
	public static boolean inList(Node<Integer> first, int num) {
		Node<Integer> temp = first;
		boolean isIn = false;
		while(temp.hasNext()) {
			if (temp.getValue() == num) {
				isIn = true;
			}
			temp = temp.getNext();
		}
		if (temp.getValue() == num) {
			isIn = true;
		}
		return isIn;
	}

	//delete the nuber from the list
	public static Node<Integer> delete(Node<Integer> first, int num) {
		Node<Integer> temp = first;
		//if the first is equal the num
		while(temp.getValue() == num) {
			first = first.getNext();
			temp = first;
		}
		//after the first
		while (temp.hasNext()) {
			//if the next is equal the num
			if (temp.getNext().getValue() == num) {
				if (temp.getNext().getNext() != null) {
					temp.setNext(temp.getNext().getNext());
				}
				//if temp.getNext has no next
				else {
					temp.setNext(null);
				}
			}
			//if the naxt isn't equal the num move on
			else {
				temp = temp.getNext();
			}
		}
		return first;
	}

	//add number after every node
	public static Node<Integer> add(Node<Integer> first, int num){
		Node<Integer> temp1 = first;
		Node<Integer> temp2;
		while (temp1.hasNext()) {
			temp2 = new Node<Integer>(num, temp1.getNext());
			temp1.setNext(temp2);
			temp1 = temp2.getNext();
		}
		temp2 = new Node<Integer>(num);
		temp1.setNext(temp2);
		return first;
	}


}
