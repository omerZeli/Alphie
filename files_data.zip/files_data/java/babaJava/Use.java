
public class Use {

	//Sports field
	public static Quiz quiz1() {
		//the number of the questions and the options per question
		final int NUM_OF_QUES = 7;
		final int NUM_OF_OPT = 4;

		//the options for all the questions
		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Orange";
		options[0][1] = "White";
		options[0][2] = "Yellow";
		options[0][3] = "I don't like colors";
		options[1][0] = "USA";
		options[1][1] = "Brazil";
		options[1][2] = "Switzerland";
		options[1][3] = "Japan";
		options[2][0] = "One hour";
		options[2][1] = "Two hours";
		options[2][2] = "Many hours";
		options[2][3] = "A few minutes";
		options[3][0] = "High jump";
		options[3][1] = "Running";
		options[3][2] = "Coordination";
		options[3][3] = "Beat";
		options[4][0] = "4";
		options[4][1] = "10";
		options[4][2] = "Sometimes with another one, most of the time alone";
		options[4][3] = "I hate working in a group";
		options[5][0] = "Hands";
		options[5][1] = "Legs";
		options[5][2] = "Both legs and hands";
		options[5][3] = "I dont have coordination";
		options[6][0] = "Its very nice";
		options[6][1] = "Its ok";
		options[6][2] = "I hate it";
		options[6][3] = "I looooove it";
		//the questions
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "What is your favorite color among these colors?";
		ques[1] = "What is your favorite country among these countries?";
		ques[2] = "How long can you do the same thing?";
		ques[3] = "Which athletic abilitie do you have?";
		ques[4] = "With how many people do you prefer to work with in a group?";
		ques[5] = "Where do you have the most coordination?";
		ques[6] = "What is your opinion about sports including touching";
		//create array of questions
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		//the final answers of the quiz
		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You would be a great basketball player - good luck!";
		answers[1] = "You would be a great soccer player - good luck!";
		answers[2] = "You would be a great tennis player - good luck!";
		answers[3] = "You would be a great judo player - good luck!";

		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "https://img.zap.co.il/pics/0/3/8/7/41387830c.gif";
		pictures[1] = "https://images-na.ssl-images-amazon.com/images/I/415Fj22VxXL.jpg";
		pictures[2] = "https://static.wixstatic.com/media/5d6071_93bc065da34e4628b87c445dec715206.jpg/v1/fill/w_498,h_332,al_c,q_90/file.jpg";
		pictures[3] = "https://files-ptdpritol.netdna-ssl.com/system/photos/505081/extra_large/e52610e2726f374bd538102a7bc4be52.jpg";

		//create the quiz
		Quiz quiz = new Quiz("Sports field", questions, answers, pictures);
		return quiz;
	}
	//which teacher are you
	public static Quiz quiz2() {
		final int NUM_OF_QUES = 8;
		final int NUM_OF_OPT = 2;

		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Java";
		options[0][1] = "Assembly";
		options[1][0] = "Woman";
		options[1][1] = "Man";
		options[2][0] = "Monday";
		options[2][1] = "Tuesday";
		options[3][0] = "Yes";
		options[3][1] = "No";
		options[4][0] = "No";
		options[4][1] = "Yes";
		options[5][0] = "Monkeys";
		options[5][1] = "Cats";
		options[6][0] = "Math";
		options[6][1] = "Systems Engeniring";
		options[7][0] = "Shavuot";
		options[7][1] = "Sukot";
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "What is your favorite programming language?";
		ques[1] = "Are you a man or a woman?";
		ques[2] = "What is your favorite day?";
		ques[3] = "Do you have a long hair?";
		ques[4] = "Did you masquerade in purim?";
		ques[5] = "What is your favorite animal?";
		ques[6] = "What is your favorite lesson (after cyber:))?";
		ques[7] = "What is your favorite holiday?";
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are Tali";
		answers[1] = "You are Shmulick";

		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "http://sfilev1.f-static.com/image/users/16584/ftp/my_files/TEACHER%20DAY.jpg";
		pictures[1] = "https://images1.ynet.co.il/PicServer4/2015/04/30/6022965/60220472575847100115no.jpg";

		Quiz quiz = new Quiz("which teacher are you", questions, answers, pictures);
		return quiz;
	}
	//the pyjamas
	public static Quiz quiz3() {
		//the number of the questions and the options per question
		final int NUM_OF_QUES = 5;
		final int NUM_OF_OPT = 3;

		//the options for all the questions
		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Piano";
		options[0][1] = "Guitar";
		options[0][2] = "Drum";
		options[1][0] = "No";
		options[1][1] = "I'm normal";
		options[1][2] = "Yes";
		options[2][0] = "Yellow";
		options[2][1] = "Green";
		options[2][2] = "Red";
		options[3][0] = "Poet";
		options[3][1] = "Photogragher";
		options[3][2] = "Waiter";
		options[4][0] = "I am not succeessful";
		options[4][1] = "I love fooooood not human";
		options[4][2] = "Not so bad";
		//the questions
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "What is your favorite musical instrument?";
		ques[1] = "Are you tall?";
		ques[2] = "What is your favorite color?";
		ques[3] = "What is your dream job?";
		ques[4] = "How much do you success in romantics?";
		//create array of questions
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		//the final answers of the quiz
		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are Illan";
		answers[1] = "You are Koby";
		answers[2] = "You are Oded";


		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "http://forumsgallery.tapuz.co.il/ForumsGallery/galleryimages/053400.jpg";
		pictures[1] = "http://albums.tapuz.co.il/mfhp-webbuilder/2/e/8/d/2015661668.jpg";
		pictures[2] = "http://pigamotsite1.weebly.com/uploads/8/1/7/7/8177679/322471518.jpg";

		//create the quiz
		Quiz quiz = new Quiz("the Pyjamas", questions, answers, pictures);
		return quiz;
	}
	//Course of would suit you
	public static Quiz quiz4() {
		final int NUM_OF_QUES = 6;
		final int NUM_OF_OPT = 2;

		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Lego";
		options[0][1] = "Xo";
		options[1][0] = "No";
		options[1][1] = "Yes";
		options[2][0] = "Pyton";
		options[2][1] = "Java";
		options[3][0] = "Robots";
		options[3][1] = "Computers";
		options[4][0] = "Free lessons";
		options[4][1] = "Finish early and go home";
		options[5][0] = "Most of the time I choose the minority view";
		options[5][1] = "Most of the time I choose the majority view";

		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "What is your favorite game?";
		ques[1] = "Are you cool?";
		ques[2] = "What is your favorite programming language?";
		ques[3] = "Which of the below do you prefer?";
		ques[4] = "Which of the below do you prefer?";
		ques[5] = "Do you tend to agree and do what the majority do, or are you OK with being an exception?";
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are in systems Engineering - go to Cyber:)";
		answers[1] = "You are in cyber - be happy!";

		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "https://www.amigo.co.il/wp-content/uploads/2016/10/LEGO_Logo-300x300.jpg";
		pictures[1] = "https://static2.timeout.co.il/media/2013/11/sizes/176217375-11_wo_680_382.jpg";

		Quiz quiz = new Quiz("Course of Study", questions, answers, pictures);
		return quiz;
	}
	//which emojy are you
	public static Quiz quiz5() {
		//the number of the questions and the options per question
		final int NUM_OF_QUES = 8;
		final int NUM_OF_OPT = 4;

		//the options for all the questions
		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Now i'm just smiling";
		options[0][1] = "Last month";
		options[0][2] = "Today";
		options[0][3] = "Never, I hate smiling";
		options[1][0] = "Smile";
		options[1][1] = "Cry";
		options[1][2] = "Laugh";
		options[1][3] = "Yell";
		options[2][0] = "Dont worry - be happy";
		options[2][1] = "Crying makes life easier";
		options[2][2] = "Live - love - laugh";
		options[2][3] = "I hate mottos!!!!!";
		options[3][0] = "I will smile and tell myself that everything will be good";
		options[3][1] = "I will start crying";
		options[3][2] = "I will laugh about the situation";
		options[3][3] = "I will yell about the man who told me i have test";
		options[4][0] = "Romans";
		options[4][1] = "Sad";
		options[4][2] = "Comedies";
		options[4][3] = "Horror";
		options[5][0] = "Tell him about the nice day i just had";
		options[5][1] = "Cry to him about something bad that always happen to me";
		options[5][2] = "Tell him a nice joke";
		options[5][3] = "Shout at him";
		options[6][0] = "I have a perfect amount of friends and they are wonderful";
		options[6][1] = "I dond have a lot of friends...";
		options[6][2] = "I dont care";
		options[6][3] = "I dont have any friends.. and if i had they were bad!!!";
		options[7][0] = "Its against all my principles";
		options[7][1] = "Its my lifestyle";
		options[7][2] = "Its a good thing to laugh on";
		options[7][3] = "I was in it ten years ago but now i understand that to be angry is the best thing!";
		//the questions
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "When did you last smiled";
		ques[1] = "What do you do most of the time?";
		ques[2] = "What is your motto in life?";
		ques[3] = "You understand that you have tommorow a big test in cyber and you forgot it, what are you doing?";
		ques[4] = "What is your favorite type of movies?";
		ques[5] = "When you meet a friend, what are you doing?";
		ques[6] = "What do you think about your amount of friends?";
		ques[7] = "What do you think about sadness?";
		//create array of questions
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		//the final answers of the quiz
		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are happy emojy!";
		answers[1] = "You are crying emojy";
		answers[2] = "You are laughing emojy";
		answers[3] = "You are angry emojy";

		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "https://i.ytimg.com/vi/yti0Goj4BHM/hqdefault.jpg";
		pictures[1] = "https://i.ytimg.com/vi/TuvmbP-SDjo/hqdefault.jpg";
		pictures[2] = "https://img.mako.co.il/2015/11/17/tears-of-joy-emoji_c.jpg";
		pictures[3] = "http://cdn.playbuzz.com/cdn/1ec99684-156e-486f-acad-908bb446cf47/f772e069-9c85-4d30-a2e8-f16817ebfff1.png";

		Quiz quiz = new Quiz("which emojy are you", questions, answers, pictures);
		return quiz;
	}
	//realistic or humanistic
	public static Quiz quiz6() {
		final int NUM_OF_QUES = 10;
		final int NUM_OF_OPT = 2;

		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Book";
		options[0][1] = "Calculator";
		options[1][0] = "I don't know, I am not good with numbers";
		options[1][1] = "60";
		options[2][0] = "A tendentious process";
		options[2][1] = "Decreasing linear function";
		options[3][0] = "A lot!!!";
		options[3][1] = "Math and phizics book - 2";
		options[4][0] = "Bright green and white";
		options[4][1] = "Dark green";
		options[5][0] = "Big and thin";
		options[5][1] = "Small and thick";
		options[6][0] = "Words";
		options[6][1] = "Numbers";
		options[7][0] = "To love my self";
		options[7][1] = "Asymptote";
		options[8][0] = "Watch movies";
		options[8][1] = "Watch videos";
		options[9][0] = "The digger one";
		options[9][1] = "The calculated one";
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "What do you always have in your bag?";
		ques[1] = "What is your grade in literature ?";
		ques[2] = "what does the word 'linear' mean to you?";
		ques[3] = "How many books did you read this month?";
		ques[4] = "What is your favorite color?";
		ques[5] = "What do you prefer?";
		ques[6] = "What do you prefer?";
		ques[7] = "What are your ambitions in life?";
		ques[8] = "What do you prefer?";
		ques[9] = "In a group, which person are you?";
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are humanistic";
		answers[1] = "You are realistic";

		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "http://www.kra-sefer.com/wp-content/uploads/2011/12/canstockphoto4297715.jpg";
		pictures[1] = "https://www.metav.co.il/4598-large_default/%D7%9E%D7%97%D7%A9%D7%91%D7%95%D7%9F-%D7%9E%D7%93%D7%A2%D7%99-%D7%A2%D7%9D-%D7%9E%D7%9B%D7%A1%D7%94-casio-fx-82ms.jpg";

		Quiz quiz = new Quiz("realistic or humanistic", questions, answers, pictures);
		return quiz;
	}
	//bake off
	public static Quiz quiz7() {
		//the number of the questions and the options per question
		final int NUM_OF_QUES = 6;
		final int NUM_OF_OPT = 3;

		//the options for all the questions
		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Chocolate";
		options[0][1] = "Fruits";
		options[0][2] = "Tomatos";
		options[1][0] = "Exaggurated";
		options[1][1] = "Trim (metuktac)";
		options[1][2] = "Creative";
		options[2][0] = "Yemen";
		options[2][1] = "Russia";
		options[2][2] = "Israel";
		options[3][0] = "this week";
		options[3][1] = "I never cried - cry is for weak";
		options[3][2] = "I never stop crying";
		options[4][0] = "At home";
		options[4][1] = "At school";
		options[4][2] = "Abroad";
		options[5][0] = "Books";
		options[5][1] = "In a formal way";
		options[5][2] = "I hate learning";
		//the questions
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "Which of the below do you prefer?";
		ques[1] = "How do you discribe yourself?";
		ques[2] = "From which country is your family?";
		ques[3] = "When did you last cry?";
		ques[4] = "Where do you prefer learning?";
		ques[5] = "In which way do you prefer learning?";
		//create array of questions
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		//the final answers of the quiz
		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are Karin Goren";
		answers[1] = "You are Estela";
		answers[2] = "You are Meir Adoni";


		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "https://img.mako.co.il/2018/01/29/Bake_Off_Judges_3_i.jpg";
		pictures[1] = "https://img.mako.co.il/2018/02/05/Bake_Off_Judges_1_i.jpg";
		pictures[2] = "https://img.mako.co.il/2018/01/29/Bake_Off_Judges_2_i.jpg";

		//create the quiz
		Quiz quiz = new Quiz("Bake off", questions, answers, pictures);
		return quiz;
	}
	//reality show
	public static Quiz quiz8() {
		//the number of the questions and the options per question
		final int NUM_OF_QUES = 6;
		final int NUM_OF_OPT = 4;

		//the options for all the questions
		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Overbearing";
		options[0][1] = "Liar";
		options[0][2] = "Fat";
		options[0][3] = "Pressed";
		options[1][0] = "2 months";
		options[1][1] = "A long time with out knowing anything";
		options[1][2] = "A day";
		options[1][3] = "A week";
		options[2][0] = "I will think about something that my best friend will most prefer";
		options[2][1] = "I will think about the thing I love the most";
		options[2][2] = "I will think about what my boss prefers";
		options[2][3] = "I will think about the thing that most of the workers love";
		options[3][0] = "To show my best freinds and family that I'm good";
		options[3][1] = "To spread my opinion to a lot of people";
		options[3][2] = "To have an opportunity";
		options[3][3] = "To improve my self";
		options[4][0] = "Work in a team";
		options[4][1] = "Live with people you dont know";
		options[4][2] = "Work in time pressure";
		options[4][3] = "Reinvent yourself";
		options[5][0] = "Eat worms";
		options[5][1] = "Lie";
		options[5][2] = "Nothing";
		options[5][3] = "Be complicated";
		//the questions
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "Which of the below least matters to you if people think about you";
		ques[1] = "What is the longest time you can be without your family?";
		ques[2] = "Your boss asks you to organize a fun day for the workers, what will you do?";
		ques[3] = "Complete the sentence- I want...";
		ques[4] = "Which challenge is the easiest for you?";
		ques[5] = "What would you do in order to win a reality show?";

		//create array of questions
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		//the final answers of the quiz
		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "The amazing race";
		answers[1] = "The big brother";
		answers[2] = "Naster Chef";
		answers[3] = "The Voice";

		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "https://media.reshet.tv/image/upload/t_app_16x9/v1510425223/%D7%94%D7%9E%D7%99%D7%A8%D7%95%D7%A5-%D7%9C%D7%9E%D7%99%D7%9C%D7%99%D7%95%D7%9F_sewfgb.jpg";
		pictures[1] = "http://actualic.co.il/wp-content/uploads/2018/01/wsi-imageoptim-d794d790d797.png";
		pictures[2] = "https://upload.wikimedia.org/wikipedia/he/thumb/1/1f/MasterChefLogo.png/250px-MasterChefLogo.png";
		pictures[3] = "http://media.reshet.tv/image/upload/t_app_16x9/v1497544225/TheVoice_u8kq6t.png";

		Quiz quiz = new Quiz("reality show", questions, answers, pictures);
		return quiz;
	}
	//disney
	public static Quiz quiz9() {
		//the number of the questions and the options per question
		final int NUM_OF_QUES = 6;
		final int NUM_OF_OPT = 3;

		//the options for all the questions
		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Im pretty";
		options[0][1] = "Im independent";
		options[0][2] = "I love kisses";
		options[1][0] = "The one who will love me";
		options[1][1] = "I don't need boys";
		options[1][2] = "The one who will kiss me";
		options[2][0] = "Blue";
		options[2][1] = "Brown";
		options[2][2] = "Orange";
		options[3][0] = "Ski vacation";
		options[3][1] = "In nature";
		options[3][2] = "In my bed";
		options[4][0] = "Family is the most important thing";
		options[4][1] = "To be feminists";
		options[4][2] = "To be the most beautiful";
		options[5][0] = "My sister";
		options[5][1] = "Myself";
		options[5][2] = "Men";
		//the questions
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "Which of the below describes you the most?";
		ques[1] = "Who is the ultimate man for you?";
		ques[2] = "What is your favorie color?";
		ques[3] = "Where is the ultimate place for you to rest?";
		ques[4] = "What is your ideology?";
		ques[5] = "Who do you trust?";
		//create array of questions
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		//the final answers of the quiz
		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are Elsa";
		answers[1] = "You are Mulan";
		answers[2] = "You are Snow White";


		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "https://i.ytimg.com/vi/-ayd06VATIk/maxresdefault.jpg";
		pictures[1] = "http://niranbd.com/newcity/movies/Mulan.jpg";
		pictures[2] = "https://maritbenisrael.files.wordpress.com/2011/03/bsnowwhite13.gif";

		//create the quiz
		Quiz quiz = new Quiz("disney princess", questions, answers, pictures);
		return quiz;
	}
	//singer
	public static Quiz quiz10() {
		final int NUM_OF_QUES = 9;
		final int NUM_OF_OPT = 2;

		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Shy";
		options[0][1] = "Full of confidence";
		options[1][0] = "Yes!!!!!!!";
		options[1][1] = "Just in special days";
		options[2][0] = "Rock";
		options[2][1] = "Mediterranean";
		options[3][0] = "Left";
		options[3][1] = "Right";
		options[4][0] = "No";
		options[4][1] = "Yes";
		options[5][0] = "Yes";
		options[5][1] = "No";
		options[6][0] = "Yes";
		options[6][1] = "No";
		options[7][0] = "Moon";
		options[7][1] = "Sun";
		options[8][0] = "No";
		options[8][1] = "Yes";
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "Are you shy or full of confidence?";
		ques[1] = "Do you love makeup?";
		ques[2] = "Which type of music do you prefer?";
		ques[3] = "Which side do you prefer?";
		ques[4] = "Do you agree with the sentence- I have eyes in the back of my head?";
		ques[5] = "Do you love TV?";
		ques[6] = "Have you been a lot abroad?";
		ques[7] = "What do you prefer?";
		ques[8] = "Do you love animals?";

		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are Aviv Gefen";
		answers[1] = "You are Eyal Golan";

		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "http://www.rimonschool.co.il/wp-content/uploads/2016/01/%D7%90%D7%91%D7%99%D7%91-%D7%92%D7%A4%D7%9F-440x310.jpg";
		pictures[1] = "http://israeliweek.com/wp-content/uploads/%D7%90%D7%99%D7%99%D7%9C-%D7%92%D7%95%D7%9C%D7%9F-%D7%95%D7%99%D7%A7%D7%99%D7%A9%D7%99%D7%AA%D7%95%D7%A3..jpg";

		Quiz quiz = new Quiz("Which singer are you", questions, answers, pictures);
		return quiz;
	}
	//Musical Instruments
	public static Quiz quiz11() {
		//the number of the questions and the options per question
		final int NUM_OF_QUES = 5;
		final int NUM_OF_OPT = 3;

		//the options for all the questions
		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "I will rest";
		options[0][1] = "I will beat someone up";
		options[0][2] = "I will take a deep breath";
		options[1][0] = "I will take him by my hands outside";
		options[1][1] = "I will scream";
		options[1][2] = "I will blow at hime untill he gets outside";
		options[2][0] = "None";
		options[2][1] = "Not so much";
		options[2][2] = "A lot of";
		options[3][0] = "Really old";
		options[3][1] = "Im a child";
		options[3][2] = "Im really young but fill graduate";
		options[4][0] = "100 years ago";
		options[4][1] = "I wont come back";
		options[4][2] = "The 60s";

		//the questions
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "When you are angry- what will you do?";
		ques[1] = "You see a cockroach (juck)- what will you do?";
		ques[2] = "How many nicknames do you have?";
		ques[3] = "How old are you?";
		ques[4] = "If you had the choice- to which time would you go back to?";

		//create array of questions
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		//the final answers of the quiz
		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "Piano";
		answers[1] = "Drums";
		answers[2] = "Saxophone";


		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "http://www.piano-world.co.il/wp-content/uploads/2017/02/Otto-Meister-xg-168.jpg";
		pictures[1] = "https://files-ptdpritol.netdna-ssl.com/system/photos/2383187/original/db3906f1995da9208efa7fc639905c6d.jpg";
		pictures[2] = "https://files-ptdpritol.netdna-ssl.com/system/photos/1258871/extra_large/9e71339eb9c9bc8c8a10919f4f68b314.jpg";

		//create the quiz
		Quiz quiz = new Quiz("Musical Instruments", questions, answers, pictures);
		return quiz;
	}
	//love life
	public static Quiz quiz12() {
		//the number of the questions and the options per question
		final int NUM_OF_QUES = 5;
		final int NUM_OF_OPT = 3;

		//the options for all the questions
		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "In the beach";
		options[0][1] = "In my house";
		options[0][2] = "In a restaurant I love and my boy/girl friend dosen't";
		options[1][0] = "the love that is in the air";
		options[1][1] = "The food";
		options[1][2] = "That my girl/boy friend pays for me";
		options[2][0] = "Every day the whole day";
		options[2][1] = "Once a week";
		options[2][2] = "Just when he/she takes me to something I love and I dont have better thing to do";
		options[3][0] = "What I live for";
		options[3][1] = "nice";
		options[3][2] = "not necessary at all";
		options[4][0] = "Its so cute";
		options[4][1] = "Its ok";
		options[4][2] = "I hate it";

		//the questions
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "Which is your favorite place for a date?";
		ques[1] = "What do you love the most in a relationships";
		ques[2] = "How much time do you want to be with your girl/boy friend?";
		ques[3] = "Complete the sentence- romantics is...";
		ques[4] = "What do you think about kitch?";

		//create array of questions
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		//the final answers of the quiz
		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You will really success in you lovely life";
		answers[1] = "If you will have good luck you will find your ONE";
		answers[2] = "You will stay single forever";


		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "http://cafe.themarker.com/media/t/548/906/file_0_big.jpg?1218341292";
		pictures[1] = "https://img.mako.co.il/2010/11/23/iStock_000008437068XSmall_c.jpg";
		pictures[2] = "https://mesibalend.co.il/wp-content/uploads/2017/10/%D7%A8%D7%95%D7%95%D7%A7.jpg";

		//create the quiz
		Quiz quiz = new Quiz("Love Life", questions, answers, pictures);
		return quiz;
	}
	//youth star
	public static Quiz quiz13() {
		//the number of the questions and the options per question
		final int NUM_OF_QUES = 6;
		final int NUM_OF_OPT = 3;

		//the options for all the questions
		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "My aunt";
		options[0][1] = "My father";
		options[0][2] = "My uncle";
		options[1][0] = "Yes its my favorite thing";
		options[1][1] = "When I was a child I liked it but now no";
		options[1][2] = "I fond it";
		options[2][0] = "Gotalent";
		options[2][1] = "Music school.. but just the first season";
		options[2][2] = "Music school";
		options[3][0] = "Black";
		options[3][1] = "I wanna be blond but Im not really...";
		options[3][2] = "Brown";
		options[4][0] = "Not really- above 10 years old";
		options[4][1] = "Yessssss- the age of 3 is the best";
		options[4][2] = "I love kids in elementary School";  
		options[5][0] = "Yesssss";
		options[5][1] = "Not really";
		options[5][2] = "Its a new hobbit- to judge kids"; 

		//the questions
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "Who is the favorite person in your family?";
		ques[1] = "Do you love TV?";
		ques[2] = "What is your favorite reality show?";
		ques[3] = "What is your hair color?";
		ques[4] = "Do you love kids?";
		ques[5] = "Do you love to judge people?";
		//create array of questions
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		//the final answers of the quiz
		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are Noa Kirel";
		answers[1] = "You are Adi Biti";
		answers[2] = "You are Agam Buchbut";


		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "https://kib.co.il/wp-content/uploads/2017/07/kirel-2.jpg";
		pictures[1] = "http://www.haverim-pro.co.il/wp-content/uploads/2016/12/%D7%A2%D7%93%D7%99-%D7%91%D7%99%D7%98%D7%99.jpg";
		pictures[2] = "https://img.mako.co.il/2016/07/11/agam_i.jpg";

		//create the quiz
		Quiz quiz = new Quiz("youth star", questions, answers, pictures);
		return quiz;
	}
	//cake
	public static Quiz quiz14() {
		//the number of the questions and the options per question
		final int NUM_OF_QUES = 5;
		final int NUM_OF_OPT = 3;

		//the options for all the questions
		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "A lot of time in the heat and then immediately freeze";
		options[0][1] = "Heat";
		options[0][2] = "Freeze";
		options[1][0] = "I'm really tall";
		options[1][1] = "I'm compact";
		options[1][2] = "I'm round ";
		options[2][0] = "That he/she will think I'm pretty";
		options[2][1] = "That he/she will love what is inside me";
		options[2][2] = "That he/she will be there all the time";
		options[3][0] = "The dominant one";
		options[3][1] = "The non important but nice one";
		options[3][2] = "The unappreciated one that everyone loves";
		options[4][0] = "Sometimes";
		options[4][1] = "Yessssss but they love me more than I love them";
		options[4][2] = "Ofcourse";  


		//the questions
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "What do you prefer?";
		ques[1] = "What is your size?";
		ques[2] = "In your boy/girl friend- what is the most important thing for you?";
		ques[3] = "In a group - who are you?";
		ques[4] = "Do you love kids?";

		//create array of questions
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		//the final answers of the quiz
		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are show cake";
		answers[1] = "You are capcake";
		answers[2] = "You are chocolate balls";


		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "https://i.ytimg.com/vi/AsnOYBE7oow/maxresdefault.jpg";
		pictures[1] = "https://d1cgjtrsdeqk19.cloudfront.net/user_image_uploads/funz/3e844d5cc6f8d73a5876be2216142eeb/medium/2018_02_25_18_21_13_____jgRyIQ_681.jpg";
		pictures[2] = "http://media.reshet.tv/image/upload/v1490715941/8850_1443891072_1443891073-1_qjemsv.jpg";

		//create the quiz
		Quiz quiz = new Quiz("which cake are you", questions, answers, pictures);
		return quiz;
	}
	//Ronaldo or Mesii
	public static Quiz quiz15() {
		final int NUM_OF_QUES = 9;
		final int NUM_OF_OPT = 2;

		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Nike";
		options[0][1] = "Adidas";
		options[1][0] = "Athletic";
		options[1][1] = "Agile";
		options[2][0] = "Europe";
		options[2][1] = "South America";
		options[3][0] = "Arrogant";
		options[3][1] = "Modest";
		options[4][0] = "Every day the whole day";
		options[4][1] = "Five minute in the morning";
		options[5][0] = "Yes";
		options[5][1] = "No";
		options[6][0] = "Go to the front";
		options[6][1] = "Go to the side";
		options[7][0] = "No";
		options[7][1] = "Yes";
		options[8][0] = "Yes";
		options[8][1] = "No";

		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "What is your favorite company?";
		ques[1] = "Are you athletic or agile?";
		ques[2] = "Which continent do you prefer?";
		ques[3] = "Are you arrogant or modest?";
		ques[4] = "How often do you engage in your hair?";
		ques[5] = "Are you tall?";
		ques[6] = "All your friends take a picture, what would you do?";
		ques[7] = "Do you prefer to stay in the same home all your life?";
		ques[8] = "Are you considered handsome?";

		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are Cristiano Ronaldo";
		answers[1] = "You are Lionel Messi";

		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "http://103fm.maariv.co.il/download/highlight/SegmentImgNew_386020_29_55_.jpg";
		pictures[1] = "http://k6s3v6r4.ssl.hwcdn.net/pictures/797/797127.jpg";

		Quiz quiz = new Quiz("Ronaldo or Messi", questions, answers, pictures);
		return quiz;
	}
	//HaAvoda or HaLikud
	public static Quiz quiz16() {
		final int NUM_OF_QUES = 7;
		final int NUM_OF_OPT = 2;

		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Over 50";
		options[0][1] = "Under 50";
		options[1][0] = "Red";
		options[1][1] = "Blue";
		options[2][0] = "Channel 10 (14)";
		options[2][1] = "Channel 20";
		options[3][0] = "Sharing is good";
		options[3][1] = "Everyone to himself is better";
		options[4][0] = "Ben Gurion";
		options[4][1] = "Jabotinsky";
		options[5][0] = "HaNoar HaOved VeHaLomed";
		options[5][1] = "The Scouting";
		options[6][0] = "It is very good idea";
		options[6][1] = "Not now, maybe in the future";


		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "What is your age?";
		ques[1] = "What is your favorite color?";
		ques[2] = "Which TV channel do you prefer?";
		ques[3] = "What do you think about sharing?";
		ques[4] = "In which street do you prefer to live?";
		ques[5] = "What is your favorite youth organizations?";
		ques[6] = "What is your opinion about women as leaders?";

		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "HaAvoda";
		answers[1] = "HaLikud";

		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "https://img.wcdn.co.il/f_auto,w_300/6/3/9/9/639979-46.jpg";
		pictures[1] = "https://kavimvenekudot.files.wordpress.com/2012/12/d79cd795d792d795-d794d79cd799d79bd795d793-d799d79ed799d7a0d7941.jpg";

		Quiz quiz = new Quiz("Which party are you", questions, answers, pictures);
		return quiz;
	}
	//kind of student
	public static Quiz quiz17() {
		//the number of the questions and the options per question
		final int NUM_OF_QUES = 6;
		final int NUM_OF_OPT = 3;

		//the options for all the questions
		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Two weeks";
		options[0][1] = "Two days";
		options[0][2] = "Hahaha test";
		options[1][0] = "The one who writes everything for anyone";
		options[1][1] = "The average";
		options[1][2] = "Hahaha Im not working";
		options[2][0] = "100";
		options[2][1] = "70";
		options[2][2] = "33";
		options[3][0] = "3 in each subject";
		options[3][1] = "1 in each subject";
		options[3][2] = "None";
		options[4][0] = "Yes ofcourse";
		options[4][1] = "They're ok with me";
		options[4][2] = "Hahaha they dont know me";  
		options[5][0] = "First line - middle";
		options[5][1] = "Third line next to a friend";
		options[5][2] = "Last line - side"; 

		//the questions
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "how much time do you learn for one test?";
		ques[1] = "In a group- who are you?";
		ques[2] = "What was your last grade?";
		ques[3] = "How many notebooks have you finished this year ?";
		ques[4] = "Do the teachers love you?";
		ques[5] = "Where is your favorite place in class?";
		//create array of questions
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		//the final answers of the quiz
		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are a nerd";
		answers[1] = "You are an average student";
		answers[2] = "You are not a good student";


		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "http://img.wcdn.co.il/f_auto,w_700,t_18/1/0/8/0/1080474-46.jpg";
		pictures[1] = "https://fscomps.fotosearch.com/compc/CSP/CSP993/%D7%A9%D7%9E%D7%97-%D7%AA%D7%9C%D7%9E%D7%99%D7%93-%D7%A7%D7%9C%D7%99%D7%A4-%D7%90%D7%A8%D7%98__k14834179.jpg";
		pictures[2] = "http://www.zofim.org.il/pics/magazin/bart2.JPG";

		//create the quiz
		Quiz quiz = new Quiz("Kind of student", questions, answers, pictures);
		return quiz;
	}
	//soccer league
	public static Quiz quiz18() {
		//the number of the questions and the options per question
		final int NUM_OF_QUES = 5;
		final int NUM_OF_OPT = 4;

		//the options for all the questions
		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "I don't support";
		options[0][1] = "I support duopoly";
		options[0][2] = "I'm very supportive";
		options[0][3] = "I don't support and don't object";
		options[1][0] = "Only if it is successful";
		options[1][1] = "I don't care";
		options[1][2] = "It's vey important";
		options[1][3] = "I support it plus export";
		options[2][0] = "White";
		options[2][1] = "Red";
		options[2][2] = "Black";
		options[2][3] = "Blue";
		options[3][0] = "I would invest all my money in my local branch";
		options[3][1] = "I would divide the money between the global to the loacl branch";
		options[3][2] = "I would invest all my money in my gloabal branch";
		options[3][3] = "I don't know";
		options[4][0] = "The company which pays the most";
		options[4][1] = "Bank";
		options[4][2] = "Phone company";
		options[4][3] = "I don't want sponsor";

		//the questions
		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "What do you think about monopoly?";
		ques[1] = "What do you think about local produce?";
		ques[2] = "What is your favorite color?";
		ques[3] = "If I had a company...";
		ques[4] = "With which company do you prefer to sign sponsoship contract?";

		//create array of questions
		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		//the final answers of the quiz
		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "Premier League - England";
		answers[1] = "La Liga - Spain";
		answers[2] = "Bundesliga - Germany";
		answers[3] = "Seria-A - Italy";

		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "https://upload.wikimedia.org/wikipedia/he/3/30/Premier_League_New_Logo.png";
		pictures[1] = "https://upload.wikimedia.org/wikipedia/commons/thumb/9/92/LaLiga_Santander.svg/500px-LaLiga_Santander.svg.png";
		pictures[2] = "https://upload.wikimedia.org/wikipedia/he/thumb/3/36/Bundesliga2.png/400px-Bundesliga2.png";
		pictures[3] = "https://upload.wikimedia.org/wikipedia/he/f/f7/LegaSerieAlogoTIM.png";

		Quiz quiz = new Quiz("Soccer league", questions, answers, pictures);
		return quiz;
	}
	//sweet or salt
	public static Quiz quiz19() {
		final int NUM_OF_QUES = 5;
		final int NUM_OF_OPT = 2;

		String[][] options = new String[NUM_OF_QUES][NUM_OF_OPT];
		options[0][0] = "Pine apple";
		options[0][1] = "Olives";
		options[1][0] = "No";
		options[1][1] = "Yes";
		options[2][0] = "C6H12O6";
		options[2][1] = "NaCl";
		options[3][0] = "Red";
		options[3][1] = "Green";
		options[4][0] = "Kineret";
		options[4][1] = "Dead Sea";


		String[] ques = new String[NUM_OF_QUES];
		ques[0] = "Which topping do you love on your pizza?";
		ques[1] = "Are you in love?";
		ques[2] = "What is your favorite substance?";
		ques[3] = "What is your favorite color?";
		ques[4] = "Which of the below do you prefer?";

		Question[] questions = new Question[NUM_OF_QUES];
		for (int i = 0; i < questions.length; i++) {
			questions[i] = new Question(ques[i], options[i]);
		}

		String[] answers = new String[NUM_OF_OPT];
		answers[0] = "You are sweet";
		answers[1] = "You are salt";

		String[] pictures = new String[NUM_OF_OPT];
		pictures[0] = "http://arcaffevents.co.il/wp-content/uploads/2017/01/NIM6606-1-350x300.jpg";
		pictures[1] = "https://i.pinimg.com/736x/00/24/97/0024970ae7dae6de7d6acab8c3f13ada--starter-recipes-bagel.jpg";

		Quiz quiz = new Quiz("sweet or salt", questions, answers, pictures);
		return quiz;
	}

	public static void main(String[] args) {

		//create array of the quizes
		final int NUM_OF_QUIZES = 19;
		Quiz[] quizes = new Quiz[NUM_OF_QUIZES];
		quizes[0] = quiz1();
		quizes[1] = quiz2();
		quizes[2] = quiz3();
		quizes[3] = quiz4();
		quizes[4] = quiz5();
		quizes[5] = quiz6();
		quizes[6] = quiz7();
		quizes[7] = quiz8();
		quizes[8] = quiz9();
		quizes[9] = quiz10();
		quizes[10] = quiz11();
		quizes[11] = quiz12();
		quizes[12] = quiz13();
		quizes[13] = quiz14();
		quizes[14] = quiz15();
		quizes[15] = quiz16();
		quizes[16] = quiz17();
		quizes[17] = quiz18();
		quizes[17] = quiz19();

		final int NUM_OF_SUBJECTS = 7;
		String[] subTitles = new String[NUM_OF_SUBJECTS];
		subTitles[0] = "Sports";
		subTitles[1] = "School";
		subTitles[2] = "TV & movies";
		subTitles[3] = "Food";
		subTitles[4] = "General";
		subTitles[5] = "Music";
		subTitles[6] = "Politics";

		//create quizes for the subjects
		Quiz[] subQuizes1 = {quiz1(),quiz15(),quiz18()};//sports
		Quiz[] subQuizes2 = {quiz2(), quiz4(),quiz6() ,quiz17()};//school
		Quiz[] subQuizes3 = {quiz3(), quiz8(), quiz9()};//tv and movies
		Quiz[] subQuizes4 = {quiz7(), quiz14(), quiz19()};// food
		Quiz[] subQuizes5 = {quiz5(), quiz12()};//general
		Quiz[] subQuizes6 = {quiz10(),quiz11() , quiz13()};//music
		Quiz[] subQuizes7 = {quiz16()};//politics

		//create the subjects
		Subject[] subject = new Subject[NUM_OF_SUBJECTS];
		subject[0] = new Subject(subTitles[0], subQuizes1);
		subject[1] = new Subject(subTitles[1], subQuizes2);
		subject[2] = new Subject(subTitles[2], subQuizes3);
		subject[3] = new Subject(subTitles[3], subQuizes4);
		subject[4] = new Subject(subTitles[4], subQuizes5);
		subject[5] = new Subject(subTitles[5], subQuizes6);
		subject[6] = new Subject(subTitles[6], subQuizes7);
		Filer filer = new Filer(quizes);

		//run the home page
		Home home  = new Home(subject, filer);

		Music.putMusic();
	}
}