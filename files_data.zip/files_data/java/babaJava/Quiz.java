
public class Quiz {
	private String title; //the title of the quiz
	private Question[] questions; //all the questions in this quiz
	private int[] saver; //array that save the answers the user chose
	private String[] finalAnswers; //the final answers of the quiz, the result of the quiz

	public Quiz(String title, Question[] questions, String[] finalAnswers) {
		this.title = title;
		this.questions = questions;
		this.saver = new int[questions.length]; //the constructor doesn't get the saver
		this.finalAnswers = finalAnswers;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Question[] getQuestions() {
		return questions;
	}

	public void setQuestions(Question[] questions) {
		this.questions = questions;
	}

	public int[] getSaver() {
		return saver;
	}

	public void setSaver(int[] saver) {
		this.saver = saver;
	}

	public String[] getFinalAnswers() {
		return finalAnswers;
	}

	public void setFinalAnswers(String[] finalAnswers) {
		this.finalAnswers = finalAnswers;
	}

	//the hezion of saver
	public int hezion(){
		int[] hadash = new int[getSaver().length];
		int saveNum;
		//crate same array like saver
		for (int i = 0; i < getSaver().length; i++) {
			hadash[i] = getSaver()[i];
		}
		//order the array for the smallest to the highest number
		for (int i = 0; i < hadash.length; i++) {
			for (int j = 0; j < hadash.length-1; j++) {
				if (hadash[j] > hadash[j+1]){
					saveNum = hadash[j];
					hadash[j] = hadash[j+1];
					hadash[j+1] = saveNum;
				}
			}
		}
		//find the hezion
		int place;
		int avg;
		if (hadash.length%2 == 1){
			place = ((hadash.length-1)/2)+1;
			return hadash[place];
		}
		else {
			place = hadash[hadash.length/2];
			avg = (hadash[place] + (hadash[place+1])/2);
			return avg;
		}
	}

	//the avarege of saver
	public int avarege() {
		int sum = 0;
		int avg;
		for (int i = 0; i < saver.length; i++) {
			sum += saver[i];
		}
		avg = sum / (saver.length);
		return avg;
	}

	//the common of saver
	public int[] common() {
		int[] hadash = new int[finalAnswers.length];
		//add the int in saver to this place of hadash
		for (int i = 0; i < saver.length; i++) {
			hadash[saver[i]]++;
		}
		int max = -1;
		int count = 0;
		//find what is the max of hadash 
		for (int i = 0; i < hadash.length; i++) {
			if (hadash[i] > max) {
				max = hadash[i];
			}

		}

		//find how much commons there are
		for (int i = 0; i < hadash.length; i++) {
			if (hadash[i] == max) {
				count++;
			}
		}

		//create array with all the commons
		int[] commons = new int[count];
		int count2 = 0;
		for (int i = 0; i < hadash.length; i++) {
			if (hadash[i] == max) {
				commons[count2] = i;
				count2++;
			}
		}

		return commons;
	}

	//the hezion of the hezion, avarege and common of saver
	public int sikum(int hezion, int avarege, int common) {
		int[] hishuv = {hezion, avarege, common};
		int saveNum;
		for (int i = 0; i < hishuv.length; i++) {
			for (int j = 0; j < hishuv.length; j++) {
				if (hishuv[j] > hishuv[j+1]) {
					saveNum = hishuv[j];
					hishuv[j] = hishuv[j+1];
					hishuv[j+1] = saveNum;
				}
			}
		}
		int place;
		int avg;
		if (hishuv.length%2 == 1){
			place = ((hishuv.length-1)/2)+1;
			return hishuv[place];
		}
		else {
			place = hishuv[hishuv.length/2];
			avg = (hishuv[place + hishuv[place+1]])/2;
			return avg;
		}
	}

	//the avarege of avarege and common of saver
	public int sikum2(int avarege, int[] common) {
		//create array with the commons and the avarege
		int[] hishuv = new int[common.length+1];
		for (int i = 0; i < common.length; i++) {
			hishuv[i] = common[i];
		}
		hishuv[hishuv.length-1] = avarege;
		int sum = 0;
		int avg;
		//find the avarege of the array (hishuv)
		for (int i = 0; i < hishuv.length; i++) {
			sum += hishuv[i];
		}
		avg = sum / hishuv.length;
		return avg;
	}
}
