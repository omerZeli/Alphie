
public class Question {
	private String theQues; //the string of the question, whats the user is asked 
	private String[] options; //the options of this question

	public Question(String theQues, String[] options) {
		this.theQues = theQues;
		this.options = options;
	}

	public String getTheQues() {
		return theQues;
	}

	public void setTheQues(String theQues) {
		this.theQues = theQues;
	}

	public String[] getOptions() {
		return options;
	}

	public void setOptions(String[] options) {
		this.options = options;
	}

}
