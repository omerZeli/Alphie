import java.awt.*;
import java.awt.event.*;

public class Home {
	//create the application with the name of the site
	public Home(Quiz[] quizes) {	
		Frame frame = new Frame("BabaJava");

		//close the app with x
		WindowListener close = new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		};
		frame.addWindowListener(close);

		//set the font and the size of the labels in the frame
		Font font = new Font("Calibri", Font.PLAIN, 30);
		frame.setFont(font);

		//label that ask the user to choose quiz
		Label instruction = new Label("choose the quiz you want to do");
		//add the label to the frame
		frame.add(instruction);
		//create array of buttons (for the quizes)
		Button[] quizButtons = new Button[quizes.length];
		for (int i = 0; i < quizButtons.length; i++) {
			//add to the buttons the name of the quizes
			quizButtons[i] = new Button(quizes[i].getTitle());
			//add the buttons to the frame
			frame.add(quizButtons[i]);
		}

		//go to the app with the quiz that the user chose
		ActionListener chooseAL = new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (int i = 0; i < quizButtons.length; i++) {
					if (e.getActionCommand().equals(quizes[i].getTitle())) {
						//go to app
						App app = new App(quizes, i);
						//close home
						frame.setVisible(false);
					}
				}
			}
		};

		//add the action listener to the buttons
		for (int i = 0; i < quizButtons.length; i++) {
			quizButtons[i].addActionListener(chooseAL);
		}

		//the order of the components
		frame.setLayout(new GridLayout(frame.getComponentCount(), 0));
		//the size of the frame (x,y)
		frame.setSize(1700, 1000);
		frame.setVisible(true);

	}
}
