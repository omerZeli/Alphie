import socket

DNS_SERVER_IP = '0.0.0.0'
DNS_SERVER_PORT = 53
DEFAULT_BUFFER_SIZE = 1024

def dns_handler(server_socket, data, addr):
    #print "data",data
    print "addr", addr
    Transaction_ID =  ":".join("{:02x}".format(ord(c)) for c in data[:2])
    Flags=  ":".join("{:02x}".format(ord(c)) for c in data[2:4])
    Questions =  ":".join("{:02x}".format(ord(c)) for c in data[4:6])
    Answer_RRs =  ":".join("{:02x}".format(ord(c)) for c in data[6:8])
    Authority_RRs =  ":".join("{:02x}".format(ord(c)) for c in data[8:10])
    Aditional_RRs =  ":".join("{:02x}".format(ord(c)) for c in data[10:12])
    Name = data[12:-3]  #":".join("{:02x}".format(ord(c)) for c in data[12:-3])
    nn = ""
    i = 0
    l = len(data[12:-3])
    while i<l-2:
        val = ord(Name[i])
        i = i+1
        for j in range(val):
            nn = nn+chr(ord(Name[i+j]))
        nn = nn+"."
        i = i+ val
    Type=  ":".join("{:02x}".format(ord(c)) for c in data[-3:-2])

    Class =  ":".join("{:02x}".format(ord(c)) for c in data[-2:])
    print "Transaction_ID",Transaction_ID
    print "Flags", Flags
    print "Questions",Questions
    print "Answer_RRs",Answer_RRs
    print "Authority_RRs",Authority_RRs
    print "Aditional_RRs",Aditional_RRs
    print "Name",nn
    print "Type",Type
    print "Class",Class

    tx_transactionId='\x00\x01'
    tx_flag = '\x85\x83'
    tx_Questions = '\x00\x01'
    tx_answer_rr= '\x00\x00'
    tx_authority_rr = '\x00\x01'
    tx_additional_rr = '\x00\x00'
    msg = tx_transactionId+tx_flag+tx_Questions+tx_answer_rr+tx_authority_rr+tx_additional_rr+Name
    print "msg",msg
    server_socket.sendto(msg,addr)

def dns_udp_server(ip, port):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    server_socket.bind((ip,port))
    print "Server started successfully! Waiting for data..."
    while True:
        try:
            data, addr = server_socket.recvfrom(DEFAULT_BUFFER_SIZE)
            dns_handler(server_socket, data, addr)
        except Exception, ex:
            print "Client exception! %s" % (str(ex),)


def main():
    print "Starting UDP server..."
    dns_udp_server(DNS_SERVER_IP, DNS_SERVER_PORT)

if __name__ == '__main__':
    main()
