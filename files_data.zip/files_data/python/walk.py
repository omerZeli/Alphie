"""
this file walk.py search for two strings like 'TextCtrl' and 'Button' in python
files
the idea is to look for example that use these strings
for example search in all wxpython book example ( recursively) all examples that
 Button appears only once and TextCtrl more than 2
"""
import os 

MAX_NMB_OF_LINE = 2000  # small file

src_path = []
for root, subdirs, files in os.walk("."):
	for x in files:
		filename = x
		extension = os.path.splitext(filename)[1]
		if extension != '.py':
			#print (filename, extension)
			continue
		#print ("1111" ,filename, extension)
		try:
				filename = root+"\\"+filename
				with open(filename, "rt") as file:
						fileContent = file.read()
						lines=fileContent.split('\n')
						numline = len(lines)
						y1 = 'TextCtrl'
						y1cnt = fileContent.count(y1)
						#if y1cnt <2  :
						#	continue
						y2 = 'tls'
						y2cnt = fileContent.count(y2)
						if y2cnt == 0:
							continue
						b = [ x for x in lines if x.count(y2)]
						a = filename, numline, y1, y1cnt,y2, y2cnt, b

						
						if numline < MAX_NMB_OF_LINE:  
							src_path.append(a)

						#print("{0} lines:{1} {2} {3} {4} {5}".format(filename, numline, y1, y1cnt,y2, y2cnt))
		except Exception as e:
				print("%s %s", filename, e)

x = sorted(src_path, key=lambda elem: elem[5] )
for i in x:
	print (i)


		
		
