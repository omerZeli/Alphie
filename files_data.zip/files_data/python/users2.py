import sqlite3

conn = sqlite3.connect('users.db')
print("ok")

conn.execute("INSERT INTO USERS (name,password) \
    VALUES ('omer', 'Omer2002')");

conn.execute("INSERT INTO USERS (name,password) \
    VALUES ('avi', 'Avi1948')");

conn.commit()
print("ok");
conn.close()