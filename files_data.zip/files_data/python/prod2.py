import sqlite3

conn = sqlite3.connect('product.db')
print("ok")

conn.execute("INSERT INTO PROD	(name,cost) \
    VALUES ('bread', 20)");

conn.execute("INSERT INTO PROD	(name,cost) \
    VALUES ('milk', 14)");

conn.commit()
print("ok");
conn.close()
