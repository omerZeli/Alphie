#http://www.c-sharpcorner.com/blogs/basics-for-displaying-image-in-tkinter-python
from Tkinter import *
from PIL import ImageTk,Image
root = Tk()
canvas = Canvas(root, width = 1000, height = 1000)
canvas.pack()
img = ImageTk.PhotoImage(Image.open("map1.png"))
canvas.create_image(20, 20, anchor=NW, image=img)

#canvas.create_line(0, 0, 1000, 1000)
root.mainloop()