from scapy.all import *

def print_pkt(packet):
    print (packet[DNS].show())    # [] - operator overloading


def filter_dns(packet):
    return (DNS in packet)   # in - membership operator

sniff(count=3,lfilter=filter_dns, prn = print_pkt)


