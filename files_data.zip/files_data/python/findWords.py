import sqlite3
import os


def create_table():
    conn = sqlite3.connect('data_base.db')
    conn.execute('''CREATE TABLE IMPORTS
                (
                the_import  TEXT    NOT NULL,
                the_file   TEXT    NOT NULL
                );''')
    conn.close()


def find_files():
    data_path = "C:\\Users\\Omer\\PycharmProjects\\proj\\files_data"
    files_list = []
    for filename in os.listdir(data_path):
        if ".txt" in filename:
            files_list.append(data_path + "\\" + filename)
        if ".py" in filename:
            files_list.append(data_path + "\\" + filename)
    return files_list


def find_imports():
    files_list = find_files()
    lines_list = []
    for path in files_list:
        file = open(path, "r")
        contents = file.read()
        lines = contents.split("\n")
        for line in lines:
            if "import" in line:
                tup = cut_lines(line, path)
                lines_list.append(tup)
        file.close()
    return lines_list


def cut_lines(line, path):
    split_line = line.split(" ")
    sec_line = split_line[1]
    split_path = path.split("\\")
    sec_path = split_path[-1]
    tup = (sec_line, sec_path)
    return tup


def insert_data():
    lines_list = find_imports()

    conn = sqlite3.connect('data_base.db')

    for i in lines_list:
        st = "INSERT INTO IMPORTS (the_import,the_file) VALUES ('{}', '{}')".format(i[0], i[1])
        conn.execute(st)

    conn.commit()
    conn.close()


def find_word(word):
    conn = sqlite3.connect('data_base.db')
    cursor = conn.execute("SELECT * from IMPORTS")
    rows = cursor.fetchall()
    for row in rows:
        if row[0] == word:
            print(row[1])


def main():
    create_table()
    insert_data()
    word = ""
    while word != "quit":
        word = input()
        find_word(word)


main()
