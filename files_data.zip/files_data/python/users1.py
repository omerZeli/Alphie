import sqlite3

conn = sqlite3.connect('users.db')
print("mush")
conn.execute('''CREATE TABLE USERS
            (
            name		TEXT    NOT NULL,
            password	TEXT	NOT NULL
            );''')
print("mush")
conn.close()