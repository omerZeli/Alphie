import socket


def main():
    print("server begin")
    server_socket = socket.socket()
    server_socket.bind(("0.0.0.0", 8820))
    server_socket.listen(1)
    (client_socket, client_address) = server_socket.accept()

    file = open("aaa.txt")
    while True:
        data = file.read(1024)
        if data == "":
            break
        client_socket.send(data.encode())


if __name__ == '__main__':
    main()
