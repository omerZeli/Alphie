# Public Key Generator
# https://www.nostarch.com/crackingcodes/ (BSD Licensed)

import random,  cryptomath

def generateKey():
  
    print('Generating p & q primes...') 
    p = 5
    q = 11
    n = p * q

    
    print('Generating e that is relatively prime to (p-1)*(q-1)...')
    while True:
        e = random.randrange(2, 40)
        if cryptomath.gcd(e, (p - 1) * (q - 1)) == 1:
            break

    print('Calculating d that is mod inverse of e...')
    d = cryptomath.findModInverse(e, (p - 1) * (q - 1))

    publicKey = (n, e)
    privateKey = (n, d)

    print('Public key:', publicKey)
    print('Private key:', privateKey)

if __name__ == '__main__':
    generateKey()
