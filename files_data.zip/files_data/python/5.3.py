#import sys
#orig_stdout = sys.stdout
from scapy.all import *
#sys.stdout = orig_stdout

def filter_http(pkt):
    if pkt.haslayer(TCP) and \
       pkt.getlayer(TCP).dport==80 and \
       pkt.haslayer(Raw):
           aa = pkt.getlayer(Raw).load
           aa = aa.decode('latin-1') #python3 - convert from byte to str
           if "GET" in aa [:10] :
            return pkt


def print_url(pkt):
    aa = aa = pkt.getlayer(Raw).load
    aa = aa.decode('latin-1')    #python3 - convert from byte to str
    rn = aa.split('\r\n')
    add = rn[0].split(' ')
    bb = add[1]
    cc = " "
    for i in rn:
        if "Host" in i:
            dd = i.split(' ')
            cc=dd[1]+bb
            break
    print(cc)
    

packets= sniff( count=40, lfilter=filter_http, prn=print_url)
#print (packets[0].show())
#print (packets[1].show())
