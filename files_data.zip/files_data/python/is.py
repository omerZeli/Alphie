import os
import sys


for filename in os.listdir(sys.argv[1]):
    print(os.path.join(sys.argv[1], filename))