import sqlite3

conn = sqlite3.connect('data_base.db')

conn.execute("INSERT INTO IMPORTS (the_import,the_file) \
    VALUES ('socket', 'client')");

conn.execute("INSERT INTO IMPORTS (the_import,the_file) \
    VALUES ('csv', 'write')");

conn.commit()
print("data was inserted");
conn.close()
