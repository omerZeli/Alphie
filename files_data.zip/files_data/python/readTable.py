import sqlite3

conn = sqlite3.connect('data_base.db')
cursor = conn.execute("SELECT * from IMPORTS")
for row in cursor:
    print(row)
