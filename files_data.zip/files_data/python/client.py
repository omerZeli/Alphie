import socket
import tkinter as tk
import threading


class client:

    def __init__(self):
        self.root = tk.Tk()

    def print_message(self, tb, text):
        tb.configure(state='normal')
        tb.insert(tk.END, text + "\n")
        tb.configure(state='disabled')

    def input_name(self, tb, fd):
        self.print_message(tb, 'hey client, welcome to the chat')
        self.print_message(tb, 'what is your name?')
        var = tk.IntVar()
        button = tk.Button(self.root, text="enter", command=lambda: var.set(1))
        button.pack()
        button.wait_variable(var)
        name = fd.get("1.0", tk.END)
        name = name.splitlines()[0]
        while name[0] == '@':
            self.print_message(tb, "username can't start with @")
            var = tk.IntVar()
            button.wait_variable(var)
            name = fd.get("1.0", tk.END)
            name = name.splitlines()[0]
        button.pack_forget()
        self.print_message(tb, name)
        return name

    def print_inst(self, tb):
        self.print_message(tb, 'write a message at this structure:')
        self.print_message(tb, '(every + in the structure is a space in the message)')
        self.print_message(tb, 'send message: 1 + the message')
        self.print_message(tb, 'appoint manager: 2 + the username')
        self.print_message(tb, 'kick out someone: 3 + the username')
        self.print_message(tb, 'silence someone: 4 + the username')
        self.print_message(tb, 'private message: 5 + the username + the message')

    def input_msg(self, tb, st, name, socket):
        sendMsg = True
        st = st.splitlines()[0]
        self.print_message(tb, st)
        tup = st.split(' ')
        msg = str(len(name)) + name + tup[0]

        ok = False
        for i in range(1, 6):
            if int(tup[0]) == i:
                ok = True
        if not ok:
            self.print_message(tb, 'this message is not legal')
        elif len(tup) < 2:
            self.print_message(tb, 'this message is not legal')
        elif int(tup[0]) == 5 and len(tup) < 3:
            self.print_message(tb, 'this message is not legal')
        else:
            if int(tup[0]) == 5:
                msg = msg + str(len(tup[1])) + tup[1]
                add = 3 + len(tup[1])
                msg = msg + st[add:]
            else:
                msg = msg + st[2:]
            msg = msg.encode()
            socket.send(msg)

    def get_msg(self, tb, socket):
        while True:
            data = socket.recv(1024)
            data = data.decode()
            self.print_message(tb, data)

    def main(self):
        print("client begin")
        my_socket = socket.socket()
        my_socket.connect(("127.0.0.1", 8820))

        self.root.geometry("500x400")

        textBox = tk.Text(self.root, height=20, width=60)
        textBox.configure(state='disabled')
        textBox.pack()
        fld = tk.Text(self.root, height=1, width=30)
        fld.pack()

        name = self.input_name(textBox, fld)
        self.print_inst(textBox)

        button = tk.Button(self.root, text="enter",
                           command=lambda: self.input_msg(textBox, fld.get("1.0", tk.END), name, my_socket))
        button.pack()

        t = threading.Thread(target=self.get_msg, args=(textBox, my_socket))
        t.start()

        self.root.mainloop()


if __name__ == '__main__':
    c = client()
    c.main()