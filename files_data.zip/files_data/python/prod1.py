import sqlite3

conn = sqlite3.connect('product.db')
print("mush")

conn.execute('''CREATE TABLE PROD
            (
            name	TEXT	NOT NULL,
            cost	INT 	NOT NULL
            );''')
print("mush")
conn.close()