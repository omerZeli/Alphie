import socket
import select
import datetime


class server:

    def __init__(self, managers=[]):
        self.managers = managers

    def send_waiting_messages(self, wlist, messages_to_send):
        for message in messages_to_send:
            (client_socket, data) = message
            dataTup = self.read_data(data)
            val = self.create_messages(dataTup)
            # if it possible to write to the socket
            if client_socket in wlist:
                val = val.encode()
                client_socket.send(val)
                messages_to_send.remove(message)

    def create_messages(self, dataTup):
        name = dataTup[1]
        command = dataTup[2]
        msg = dataTup[3]
        clock = datetime.datetime.now()
        clock = str(clock)[11:-10]
        if name in self.managers:
            name = '@' + name
        if command == 1:
            if self.special_msg(msg):
                val = clock + ', ' + msg
            elif msg == 'quit':
                val = clock + ', ' + name + ' has left the chat!'
            elif msg == 'view-managers':
                val = clock + ', ' + str(self.managers)
            else:
                val = clock + ', ' + name + ': ' + msg
        elif command == 3:
            if self.special_msg(msg):
                val = clock + ', ' + msg
            else:
                val = clock + ', ' + msg + ' has been kicked from the chat!'
        elif command == 2:
            if self.special_msg(msg):
                val = clock + ', ' + msg
            else:
                val = clock + ', ' + name + ' appoint ' + msg + ' manager'
        elif command == 4:
            if self.special_msg(msg):
                val = clock + ', ' + msg
            else:
                val = clock + ', ' + name + ' silence ' + msg
        elif command == 5:
            if self.special_msg(msg):
                val = clock + ', ' + msg
            else:
                the_msg = self.read_private_data(msg)[2]
                val = clock + ', !' + name + ': ' + the_msg
        return val

    def special_msg(self, msg):
        if msg == "you are not a manager":
            return True
        elif msg == "you sent a name that not in the chat":
            return True
        elif msg == "you can't speak here":
            return True
        else:
            return False

    def read_data(self, data):
        nameLen = int(data[0])
        name = data[1:1 + nameLen]
        command = int(data[1 + nameLen])
        msg = data[2 + nameLen:]
        return [nameLen, name, command, msg]

    def read_private_data(self, msg):
        sec_len_name = int(msg[0])
        sec_name = msg[1:1 + sec_len_name]
        the_msg = msg[1 + sec_len_name:]
        return [sec_len_name, sec_name, the_msg]

    def in_list(self, clients_names, name):
        for names in clients_names:
            if names[1] == name:
                return True
        return False

    def main(self):
        print("server begin")
        server_socket = socket.socket()
        server_socket.bind(('0.0.0.0', 8820))
        server_socket.listen(1)
        open_client_sockets = []
        clients_names = []
        messages_to_send = []
        manager = True
        silence = []

        while True:
            rlist, wlist, xlist = select.select([server_socket] + open_client_sockets, open_client_sockets, [])
            for current_socket in rlist:
                if current_socket is server_socket:
                    (new_socket, address) = server_socket.accept()
                    open_client_sockets.append(new_socket)
                    clients_names.append([new_socket, ''])
                else:
                    data = current_socket.recv(1024)
                    data = data.decode()
                    [lenName, name, command, msg] = self.read_data(data)
                    for soc in clients_names:
                        if soc[0] is current_socket:
                            if soc[1] == '':
                                soc[1] = name
                    if manager:
                        self.managers.append(name)
                        manager = False

                    if name in silence:
                        if msg == 'quit':
                            open_client_sockets.remove(current_socket)
                            for tup_socket in clients_names:
                                if tup_socket[0] is current_socket:
                                    clients_names.remove(tup_socket)
                            silence.remove(name)
                            if name in self.managers:
                                self.managers.remove(name)
                            for the_socket in open_client_sockets:
                                messages_to_send.append((the_socket, data))
                        data = str(lenName) + name + str(command) + "you can't speak here"
                        messages_to_send.append((current_socket, data))
                    elif command == 1:
                        if msg == "quit":
                            open_client_sockets.remove(current_socket)
                            for tup_socket in clients_names:
                                if tup_socket[0] is current_socket:
                                    clients_names.remove(tup_socket)
                            if name in self.managersrs:
                                self.managers.remove(name)
                            for the_socket in open_client_sockets:
                                messages_to_send.append((the_socket, data))
                        elif msg == 'view-managers':
                            messages_to_send.append((current_socket, data))
                        else:
                            for the_socket in open_client_sockets:
                                if the_socket is not current_socket:
                                    messages_to_send.append((the_socket, data))
                    elif command == 3:
                        if not self.in_list(clients_names, msg):
                            data = str(lenName) + name + str(command) + "you sent a name that not in the chat"
                            messages_to_send.append((current_socket, data))
                        else:
                            if name in self.managers:
                                for out_socket in clients_names:
                                    if out_socket[1] == msg:
                                        open_client_sockets.remove(out_socket[0])
                                        clients_names.remove(out_socket)
                                        if out_socket[1] in self.managers:
                                            self.managers.remove(out_socket[1])
                                for the_socket in open_client_sockets:
                                    messages_to_send.append((the_socket, data))
                            else:
                                data = str(lenName) + name + str(command) + "you are not a manager"
                                messages_to_send.append((current_socket, data))
                    elif command == 2:
                        if not self.in_list(clients_names, msg):
                            data = str(lenName) + name + str(command) + "you sent a name that not in the chat"
                            messages_to_send.append((current_socket, data))
                        else:
                            if name in self.managers:
                                self.managers.append(msg)
                                for the_socket in open_client_sockets:
                                    messages_to_send.append((the_socket, data))
                            else:
                                data = str(lenName) + name + str(command) + "you are not a manager"
                                messages_to_send.append((current_socket, data))
                    elif command == 4:
                        if not self.in_list(clients_names, msg):
                            data = str(lenName) + name + str(command) + "you sent a name that not in the chat"
                            messages_to_send.append((current_socket, data))
                        else:
                            if name in self.managers:
                                silence.append(msg)
                                for the_socket in open_client_sockets:
                                    messages_to_send.append((the_socket, data))
                            else:
                                data = str(lenName) + name + str(command) + "you are not a manager"
                                messages_to_send.append((current_socket, data))
                    elif command == 5:
                        [sec_len_name, sec_name, the_msg] = self.read_private_data(msg)
                        if not self.in_list(clients_names, sec_name):
                            data = str(lenName) + name + str(command) + "you sent a name that not in the chat"
                            messages_to_send.append((current_socket, data))
                        else:
                            for send_socket in clients_names:
                                if send_socket[1] == sec_name:
                                    to_send = send_socket[0]
                            messages_to_send.append((to_send, data))
            self.send_waiting_messages(wlist, messages_to_send)


if __name__ == '__main__':
    c = server()
    c.main()