import socket

print("client begin")
my_socket = socket.socket()
my_socket.connect(("127.0.0.1", 8820))

data = " "
while data != "":
    data = my_socket.recv(1024)
    data = data.decode()
    print(data)
