#run this file from cmd - python add4.py 1 2 3 4
import sys

def add4(a,b,c,d):
    sum = a + b + c + d
    #print "add4 sum:", sum
    msg="<!DOCTYPE html>"
    msg = msg + "<html xmlns=\"http://www.w3.org/1999/xhtml\">"
    msg = msg+"<head>  <title>add4</title> </head><body>"
    msg = msg+"<form id=\"form1\" action=\"add4.py\" method=\"get\">"
    msg = msg + "enter number<input id=\"nmb1\" type=\"text\" name=\"nmb1\" value=\""+str(a)+"\"/><br/>"
    msg = msg + "enter number<input id=\"nmb2\" type=\"text\" name=\"nmb2\" value=\"" +str(b)+"\"/><br/>"
    msg = msg + "enter number<input id=\"nmb3\" type=\"text\" name=\"nmb3\" value=\"" + str(c)+"\"/><br/>"
    msg = msg + "enter number<input id=\"nmb4\" type=\"text\" name=\"nmb4\" value=\"" + str(d) + "\"/><br/>"
    msg = msg + "<input type=\"submit\"/>"
    msg = msg + "result <input id=\"result\" type=\"text\" value=\""+str(sum)+"\"/><br/>"
    msg = msg + "</form></body></html>"
    print msg
    return msg


if __name__ == "__main__":
    a = int(sys.argv[1])
    b = int(sys.argv[2])
    c = int(sys.argv[3])
    d = int(sys.argv[4])
    add4(a, b , c, d)